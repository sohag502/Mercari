#include <jni.h>
#include <string>

extern "C" JNIEXPORT jstring
JNICALL
Java_com_decodelab_mercari_SplashActivity_stringFromJNI(
        JNIEnv *env,
        jobject /* this */) {
    std::string hello = "WelCome To Mercari";
    return env->NewStringUTF(hello.c_str());
}

extern "C" JNIEXPORT jstring
JNICALL
Java_com_decodelab_mercari_fragment_AllFragment_stringAllUrl(
        JNIEnv *env,
        jobject /* this */) {
    std::string hello = "https://s3-ap-northeast-1.amazonaws.com/m-et/Android/json/all.json";
    return env->NewStringUTF(hello.c_str());
}

extern "C" JNIEXPORT jstring
JNICALL
Java_com_decodelab_mercari_fragment_ManFragment_stringMenUrl(
        JNIEnv *env,
        jobject /* this */) {
    std::string hello = "https://s3-ap-northeast-1.amazonaws.com/m-et/Android/json/men.json";
    return env->NewStringUTF(hello.c_str());
}

extern "C" JNIEXPORT jstring
JNICALL
Java_com_decodelab_mercari_fragment_WomanFragment_stringWomenUrl(
        JNIEnv *env,
        jobject /* this */) {
    std::string hello = "https://s3-ap-northeast-1.amazonaws.com/m-et/Android/json/women.json";
    return env->NewStringUTF(hello.c_str());
}
