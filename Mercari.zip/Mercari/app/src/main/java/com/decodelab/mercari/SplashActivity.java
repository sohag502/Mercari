package com.decodelab.mercari;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.decodelab.mercari.activity.MainActivity;

public class SplashActivity extends AppCompatActivity {

    Context con;

    Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        con = this;

        // L.e("status", ""+PersistentUser.isLogged(con));

        handler.postDelayed(new Runnable() {

            @Override
            public void run() {
                final Intent in = new Intent(con, MainActivity.class);
                startActivity(in);
                SplashActivity.this.finish();
            }
        }, 2000);
    }
}
