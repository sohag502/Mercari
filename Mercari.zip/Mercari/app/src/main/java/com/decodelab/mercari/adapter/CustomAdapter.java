package com.decodelab.mercari.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.decodelab.mercari.R;
import com.decodelab.mercari.service.IdName;


import java.util.ArrayList;

public class CustomAdapter extends BaseAdapter {

    ArrayList<IdName> myList ;
    LayoutInflater inflater;
    Context context;

    public CustomAdapter(Context context, ArrayList<IdName> objects) {
        this.myList = objects;
        this.context = context;
        inflater = LayoutInflater.from(this.context);

    }

    @Override
    public int getCount() {
        return myList.size();
    }

    @Override
    public Object getItem(int position) {
        return myList.get(position);
    }
    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        MyViewHolder mViewHolder;

        if (convertView == null) {
            convertView = inflater.inflate(R.layout.list_item, parent, false);
            mViewHolder = new MyViewHolder(convertView);

            convertView.setTag(mViewHolder);
        } else {
            mViewHolder = (MyViewHolder) convertView.getTag();
        }


        //BIND DATA
        IdName d = (IdName) this.myList.get(position);


        if(d.getName() !=null && !d.getName().isEmpty()){

            mViewHolder.txName.setText(d.getName());
        }else{
            mViewHolder.imName.setVisibility(View.GONE);
        }

        if(d.getNum_likes() !=null && !d.getNum_likes().isEmpty()){

            mViewHolder.txLike.setText(d.getNum_likes());
        }else{
            mViewHolder.txLike.setVisibility(View.GONE);
        }

        if(d.getNum_comments() !=null && !d.getNum_comments().isEmpty()){

            mViewHolder.txComment.setText(d.getNum_comments());
        }else{
            mViewHolder.txComment.setVisibility(View.GONE);
        }

        if(d.getPrice() !=null && !d.getPrice().isEmpty()){

            mViewHolder.txPrice.setText("$ "+d.getPrice());
        }else{
            mViewHolder.txPrice.setVisibility(View.GONE);
        }

        if(d.getStatus() !=null && !d.getStatus().isEmpty()){
            if(d.getStatus().equals("sold_out")){
                mViewHolder.soldIn.setVisibility(View.VISIBLE);
            }else {
                mViewHolder.soldIn.setVisibility(View.GONE);
            }

        }else{
            mViewHolder.txPrice.setVisibility(View.GONE);
        }

        if(d.getPhoto() !=null && !d.getPhoto().isEmpty()){

            Glide.with(context)
                    .load(d.getPhoto())
                    .into(mViewHolder.imName);

        }else{
            mViewHolder.imName.setVisibility(View.GONE);
        }


        return convertView;
    }

    private class MyViewHolder {
        TextView txName,txLike,txComment,txPrice;
        ImageView imName,soldIn;

        public MyViewHolder(View item) {

            txName= (TextView) item.findViewById(R.id.txName);
            imName= (ImageView) item.findViewById(R.id.imName);
            soldIn= (ImageView) item.findViewById(R.id.soldIn);
            txLike= (TextView) item.findViewById(R.id.txLike);
            txComment= (TextView) item.findViewById(R.id.txComment);
            txPrice= (TextView) item.findViewById(R.id.txPrice);

        }
    }


}