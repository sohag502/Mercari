package com.decodelab.mercari.adapter;


import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import com.decodelab.mercari.fragment.AllFragment;
import com.decodelab.mercari.fragment.ManFragment;
import com.decodelab.mercari.fragment.WomanFragment;


public class TabsPagerAdapter extends FragmentStatePagerAdapter {

    private  int numberTabs;

    public TabsPagerAdapter(FragmentManager fm, int numberTabs) {
        super(fm);
        this.numberTabs = numberTabs;
    }

    public Fragment getItem(int index) {

        switch (index) {
                case 0:
                ManFragment  Men = new ManFragment();
                return  Men;
                case 1:
                AllFragment  All = new AllFragment();
                return  All;
                case 2:
                WomanFragment  Women = new WomanFragment();
                return  Women;

        }

        return null;
    }

    public int getCount() {

        return numberTabs;
    }
}

