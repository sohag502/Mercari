package com.decodelab.mercari.fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.Toast;

import com.decodelab.mercari.NetworkCheck;
import com.decodelab.mercari.R;
import com.decodelab.mercari.adapter.CustomAdapter;
import com.decodelab.mercari.service.ApiCall;
import com.decodelab.mercari.service.IdName;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;

public class AllFragment  extends Fragment {
    private String id,name,status,num_likes,num_comments,price,photo;
    private GridView lsAll;
    private CustomAdapter customAdapter;
    private ArrayList<IdName> idNames;
    static {
        System.loadLibrary("native-lib");
    }
    private OkHttpClient client;
    private static final int SUCCESS = 1;
    private static final int FAILURE = 0;
    public static native String stringAllUrl();
    private NetworkCheck networkCheck;
    ProgressDialog progressDialog;
    Context context;
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.all_fragment, container, false);

        lsAll=(GridView) rootView.findViewById(R.id.lsAll);
        idNames=new ArrayList<IdName>();
        networkCheck=new NetworkCheck();
        client = new OkHttpClient.Builder() .connectTimeout(100, TimeUnit.SECONDS).readTimeout(100, TimeUnit.SECONDS) .writeTimeout(100, TimeUnit.SECONDS).build();

        if (!networkCheck.isConnect(getActivity())) {
            AlertDialog.Builder alert = new AlertDialog.Builder(getActivity());
            alert.setTitle("No Internet Connection");
            alert.setMessage("Please Connect to INTERNET  to view  All List");
            alert.setNegativeButton("Cancel",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();

                        }
                    });
            alert.setPositiveButton("Settings",
                    new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface arg0, int arg1) {
                            // TODO Auto-generated method stub
                            getActivity().startActivity(new Intent(
                                    Settings.ACTION_WIFI_SETTINGS));
                        }
                    });
            alert.show();
        }

        else{
            progressDialog = new ProgressDialog(getActivity(),
                    R.style.AppTheme_Dark_Dialog);
            progressDialog.setIndeterminate(true);
            progressDialog.setMessage("Please wait .....");
            progressDialog.show();

            AllData(stringAllUrl());
        }

        return rootView;
    }

    private void AllData(String gcmURL) {

        new AsyncTask<String, Void, Void>() {
            @Override
            protected Void doInBackground(String... params) {

                try {
                    String  response = ApiCall.GET(
                            client,
                            params[0]
                            );

                    JSONArray jsonArray = new JSONArray(response);
                    int size = jsonArray.length();
                    if(size>0){
                        for (int i = 0; i < size; i++) {
                            JSONObject stOBJ = jsonArray.getJSONObject(i);
                            id = stOBJ.getString("id");
                            name = stOBJ.getString("name");
                            status = stOBJ.getString("status");
                            num_likes = stOBJ.getString("num_likes");
                            num_comments = stOBJ.getString("num_comments");
                            price = stOBJ.getString("price");
                            photo = stOBJ.getString("photo");


                            Log.i("ddddd", "get Data " + photo);
                            IdName ii=new IdName(id,name,status,num_likes,num_comments,price,photo);
                            idNames.add(ii);

                        }



                        AllThreadhandler.sendEmptyMessage(SUCCESS);
                    }else {
                        AllThreadhandler.sendEmptyMessage(FAILURE);
                    }


                    Log.d("Response", response);
                } catch (IOException e) {
                    AllThreadhandler.sendEmptyMessage(FAILURE);
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                    AllThreadhandler.sendEmptyMessage(FAILURE);
                }
                return null;
            }
        }.execute(gcmURL);
    }

    Handler AllThreadhandler = new Handler() {
        public void handleMessage(android.os.Message msg) {
            if (msg.what == SUCCESS) {
               customAdapter=new CustomAdapter(getActivity(),idNames);
               lsAll.setAdapter(customAdapter);
              progressDialog.dismiss();

            } else {

                Toast.makeText(getActivity(),"Load Data Error",Toast.LENGTH_LONG).show();
                progressDialog.dismiss();

            }
        }
    };
}
